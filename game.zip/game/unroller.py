set_type = python_set = set
python_dict = dict
last_save_caption = ''
crash_ignored = None

compacted_translations = dict()
tagless_translations = dict()

newest_save = newest_autosave = None
save_notes =''
